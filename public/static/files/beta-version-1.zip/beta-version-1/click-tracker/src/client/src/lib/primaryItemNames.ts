import { TItemName_primary } from './types';

export const primaryItemNames: TItemName_primary[] = [
    'Affiliate Networks',
    'Campaigns',
    'Flows',
    'Landing Pages',
    'Offers',
    'Traffic Sources'
];
