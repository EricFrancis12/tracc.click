import { TLandingPageRotation, TOfferRotation } from './types';

export const landingPageRotationOptions: TLandingPageRotation[] = [
    'random'
];

export const offerRotationOptions: TOfferRotation[] = [
    'random'
];
