import { TLogicalRelation } from './types';

export const logicalRelations: TLogicalRelation[] = [
    'and',
    'or'
];
