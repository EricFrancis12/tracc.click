import type { TFlowType } from './types';

export const flowTypes: TFlowType[] = [
    'saved',
    'built_in',
    'url'
];
